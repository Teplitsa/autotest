<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_---   ---</name>
   <tag></tag>
   <elementGuidId>789b0d12-e780-4689-ab75-7f8a6fd579da</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.ui-selectmenu-text</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[@id='payment-type-select-button']/span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>b4714ec2-552f-4f32-8e4c-bf4a0b883bcb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ui-selectmenu-text</value>
      <webElementGuid>91679bcc-2267-4a3a-aa4e-aee118676de8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                        --- Тип пожертвования ---
                                    </value>
      <webElementGuid>c5d09471-38bf-423d-8d93-c88ff113f833</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;payment-type-select-button&quot;)/span[@class=&quot;ui-selectmenu-text&quot;]</value>
      <webElementGuid>30cd0b70-0aac-41b3-bb5a-e7f173aeed7a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//span[@id='payment-type-select-button']/span[2]</value>
      <webElementGuid>d7d39f7c-2a2f-41d8-8d8f-e84587b48a59</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Добавить корректировочное пожертвование'])[1]/following::span[3]</value>
      <webElementGuid>5b5f35ef-90f8-434b-aa8e-5bc81bab140c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Пожертвования'])[4]/following::span[3]</value>
      <webElementGuid>7771d027-188d-4ad9-a69c-a3b4011258e5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='--- Статус пожертвования ---'])[2]/preceding::span[2]</value>
      <webElementGuid>274736c0-6c57-4503-93b8-99e1205992c0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='От:'])[1]/preceding::span[4]</value>
      <webElementGuid>8566e0cd-62ec-416b-97c0-2557d206d504</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/span/span[2]</value>
      <webElementGuid>1de28437-b6e9-4698-83b2-1461d86b66ee</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
                                        --- Тип пожертвования ---
                                    ' or . = '
                                        --- Тип пожертвования ---
                                    ')]</value>
      <webElementGuid>c215b38f-e6a1-4d45-bc49-e9aa592033a2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
