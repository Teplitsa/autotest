<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_,      .     ,</name>
   <tag></tag>
   <elementGuidId>358eb8f6-e3ac-4538-93b0-00f7e14b7297</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#leyka_donor_accounts_available-wrapper > label > span.field-component.field</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='leyka_donor_accounts_available-wrapper']/label/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>8dca27e3-cff7-436b-8d13-49c4a5d2670b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>field-component field</value>
      <webElementGuid>292c10d6-2009-4a00-9226-fe2c9a663a8c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>

                 

            Включить личные кабинеты доноров                    
                    
                    Отметьте, чтобы включить функции личных кабинетов доноров. На сайте появятся специальные страницы, где доноры смогут получить информацию о сделанных ими пожертвованиях и управлять своими рекуррентными подписками.
                
                            </value>
      <webElementGuid>a7a9e7d7-0079-45a7-8545-3a8a55ed1354</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;leyka_donor_accounts_available-wrapper&quot;)/label[1]/span[@class=&quot;field-component field&quot;]</value>
      <webElementGuid>f4baade2-bef1-441b-af3a-a259a144fe1d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='leyka_donor_accounts_available-wrapper']/label/span</value>
      <webElementGuid>773a2b0c-becb-4eeb-a115-1441894634d6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Настройки доноров и аккаунтов'])[1]/following::span[4]</value>
      <webElementGuid>e8c7e887-9495-49a9-aec8-e1e940b341d5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Дополнительно'])[1]/preceding::span[3]</value>
      <webElementGuid>f2f2df3a-5c63-49b2-ae4b-817b50518c8a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form[4]/div/div[2]/div[2]/label/span</value>
      <webElementGuid>6581dd7a-fc4f-49c0-9624-6787b6ff2742</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '

                 

            Включить личные кабинеты доноров                    
                    
                    Отметьте, чтобы включить функции личных кабинетов доноров. На сайте появятся специальные страницы, где доноры смогут получить информацию о сделанных ими пожертвованиях и управлять своими рекуррентными подписками.
                
                            ' or . = '

                 

            Включить личные кабинеты доноров                    
                    
                    Отметьте, чтобы включить функции личных кабинетов доноров. На сайте появятся специальные страницы, где доноры смогут получить информацию о сделанных ими пожертвованиях и управлять своими рекуррентными подписками.
                
                            ')]</value>
      <webElementGuid>79d61bcc-7516-4293-9d65-42ec375f10f1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
