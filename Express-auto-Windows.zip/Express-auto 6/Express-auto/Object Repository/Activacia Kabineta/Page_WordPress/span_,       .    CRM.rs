<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_,       .    CRM</name>
   <tag></tag>
   <elementGuidId>c3c956b4-84bc-4f64-967d-531e3c368bb9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#leyka_donor_management_available-wrapper > label > span.field-component.field</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='leyka_donor_management_available-wrapper']/label/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>4e679d81-bcb8-49b9-a552-f9ce6e115aef</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>field-component field</value>
      <webElementGuid>9263423f-add3-4948-af0e-22567fad7cfd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>

                 

            Включить функции управления донорами                    
                    
                    Отметьте, чтобы автоматически регистрировать доноров для всех пожертвований. Это активирует функции CRM и добавляет дополнительные страницы управления донорами в область администрирования плагина.
                
                            </value>
      <webElementGuid>f68cc576-d898-43ac-8441-0823fe4fae5c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;leyka_donor_management_available-wrapper&quot;)/label[1]/span[@class=&quot;field-component field&quot;]</value>
      <webElementGuid>e2d7f559-a8cd-4c84-903c-e67df2ff0a1e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='leyka_donor_management_available-wrapper']/label/span</value>
      <webElementGuid>d5259b35-72ed-4263-a6b6-fcd4cc6f4aab</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Настройки доноров и аккаунтов'])[1]/following::span[1]</value>
      <webElementGuid>efd56f60-a59b-45d9-8a64-68734928a3e6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='*'])[5]/following::span[2]</value>
      <webElementGuid>23543292-1c2b-4f0b-b5a7-20d680d3d485</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Дополнительно'])[1]/preceding::span[6]</value>
      <webElementGuid>f71cd9e2-8dd2-400c-9c6c-1cb3d77e469b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form[4]/div/div[2]/div/label/span</value>
      <webElementGuid>e1022269-db8f-4b21-9386-2785eeb4d2f8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '

                 

            Включить функции управления донорами                    
                    
                    Отметьте, чтобы автоматически регистрировать доноров для всех пожертвований. Это активирует функции CRM и добавляет дополнительные страницы управления донорами в область администрирования плагина.
                
                            ' or . = '

                 

            Включить функции управления донорами                    
                    
                    Отметьте, чтобы автоматически регистрировать доноров для всех пожертвований. Это активирует функции CRM и добавляет дополнительные страницы управления донорами в область администрирования плагина.
                
                            ')]</value>
      <webElementGuid>ffff110d-27fb-42e4-823c-330cec2d97da</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
