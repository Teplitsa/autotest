<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_0</name>
   <tag></tag>
   <elementGuidId>ef5a3696-2fe6-46a0-b267-75a29a46dd23</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.leyka-scale-label > span</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//tr[@id='post-268']/td[4]/div/div[2]/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>456e8e1c-d3aa-4412-bef5-231a5dbf41c6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        Собрано: 0 €    </value>
      <webElementGuid>88e0bc06-7da8-43a8-ba49-a8d469ddbe24</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;post-268&quot;)/td[@class=&quot;target column-target&quot;]/div[@class=&quot;leyka-scale-ultra-fake&quot;]/div[@class=&quot;leyka-scale-label&quot;]/span[1]</value>
      <webElementGuid>dafb0ad8-7eea-4bb0-ac07-9f54df58d8de</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//tr[@id='post-268']/td[4]/div/div[2]/span</value>
      <webElementGuid>8a76233f-ee66-473c-8524-17461fb74c41</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Открыт'])[2]/following::span[1]</value>
      <webElementGuid>b607b69d-8f60-4a09-81e6-cac9411f135b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Показать больше деталей'])[1]/following::span[2]</value>
      <webElementGuid>b988605b-090b-4269-861a-84fab67182fc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Не трогать, проверка прогресса'])[3]/preceding::span[1]</value>
      <webElementGuid>6ae4ac2e-4af7-4799-aa7e-267dec3592ed</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Опубликовано21.10.2022 в 12:45'])[1]/preceding::span[1]</value>
      <webElementGuid>25a0f34e-074b-4909-961d-5c46c705d9b1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Собрано:']/parent::*</value>
      <webElementGuid>672b6c71-b9de-487f-ae1e-ce2bdb177c64</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div[2]/span</value>
      <webElementGuid>138282c7-7aea-4baf-aeb6-53b774236f83</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
        Собрано: 0 €    ' or . = '
        Собрано: 0 €    ')]</value>
      <webElementGuid>43c67706-56b5-4824-9fb9-0b1bda7bad6b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
