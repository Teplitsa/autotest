<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_</name>
   <tag></tag>
   <elementGuidId>c4cd1fde-04ff-4989-aa86-949329f0a794</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='leyka-pf-18-star-form']/div[5]/div[2]/div[2]/div/label/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.donor__textfield.donor__textfield--name.required > div.leyka-star-field-frame > label > span.donor__textfield-label.leyka_donor_name-label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>2390bd17-5dab-4c64-b791-f68e9f7d0c6b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>donor__textfield-label leyka_donor_name-label</value>
      <webElementGuid>476d04cd-0255-40dd-9969-cebaffdd6c3c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                            Имя и Фамилия                        </value>
      <webElementGuid>1f1608be-eb11-4ae1-b983-3c57bf0db2da</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;leyka-pf-18-star-form&quot;)/div[@class=&quot;section section--person&quot;]/div[@class=&quot;section__fields donor&quot;]/div[@class=&quot;donor__textfield donor__textfield--name required&quot;]/div[@class=&quot;leyka-star-field-frame&quot;]/label[1]/span[@class=&quot;donor__textfield-label leyka_donor_name-label&quot;]</value>
      <webElementGuid>8313729b-bf15-4d85-9472-040dd8f85d6e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='leyka-pf-18-star-form']/div[5]/div[2]/div[2]/div/label/span</value>
      <webElementGuid>ddd2c814-2af2-4c81-b84e-03a80527a539</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Укажите корректный адрес email'])[1]/following::span[1]</value>
      <webElementGuid>41d7b42d-f22f-4b22-bb4a-1f749eea7746</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ваш email'])[1]/following::span[2]</value>
      <webElementGuid>06fd6e9f-af8c-4a9a-a7e0-1e1de2b25fbf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Укажите ваше имя'])[1]/preceding::span[1]</value>
      <webElementGuid>0cd5e516-e949-42a2-b8e0-ea82b1e6dfe7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Имя и Фамилия']/parent::*</value>
      <webElementGuid>f92606d8-30de-473c-a3e8-fdf5e16d43c1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/label/span</value>
      <webElementGuid>73be55da-1f92-409f-baec-74b2f47ff3ce</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
                            Имя и Фамилия                        ' or . = '
                            Имя и Фамилия                        ')]</value>
      <webElementGuid>b88cea3d-f0f1-4ea4-9f76-354c1a7c1709</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
