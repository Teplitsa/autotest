<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_</name>
   <tag></tag>
   <elementGuidId>49867e05-48a9-4f8d-be51-02474554b517</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='leyka-pf-18-star-form']/div[5]/div[2]/div[3]/span/label</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span > label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>e7fed36e-c328-46a0-aca7-026079bb6894</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>for</name>
      <type>Main</type>
      <value>leyka-3243655051</value>
      <webElementGuid>1262321b-ef66-4f1d-b482-9c1a960b8576</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                        

                    Соглашаюсь с                         
                                        офертой                        
                    </value>
      <webElementGuid>efa450da-e4cc-4192-9663-27aba02adad0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;leyka-pf-18-star-form&quot;)/div[@class=&quot;section section--person&quot;]/div[@class=&quot;section__fields donor&quot;]/div[@class=&quot;donor__oferta&quot;]/span[1]/label[1]</value>
      <webElementGuid>2d15d032-6ecd-4f81-b68b-7b6a1249e6dd</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='leyka-pf-18-star-form']/div[5]/div[2]/div[3]/span/label</value>
      <webElementGuid>5e7836ea-8ecf-45c5-971b-f2bd8cc21fa8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Укажите ваше имя'])[1]/following::label[1]</value>
      <webElementGuid>86d96b2e-7a67-43f0-b150-173f6be45bc6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Имя и Фамилия'])[1]/following::label[1]</value>
      <webElementGuid>0807af61-176f-41c9-bfac-c7fc048c1764</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Соглашаюсь с']/parent::*</value>
      <webElementGuid>1cf9523d-6c2c-49a1-b8d7-c94efcfa9998</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span/label</value>
      <webElementGuid>57987403-f53d-4b09-9c7a-2f1a7ade6e3c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = '
                        

                    Соглашаюсь с                         
                                        офертой                        
                    ' or . = '
                        

                    Соглашаюсь с                         
                                        офертой                        
                    ')]</value>
      <webElementGuid>08f8a6c0-7009-4b4e-8fa1-db2f336f3069</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
