<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label__1</name>
   <tag></tag>
   <elementGuidId>f81f5141-25c6-494f-a197-7acd8736098b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='leyka-pf-18-star-form']/div[5]/div[2]/div[3]/span/label[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>57de0e70-05c2-4fda-9e14-a22c8dbbf5c3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>for</name>
      <type>Main</type>
      <value>leyka-2472145131</value>
      <webElementGuid>a4c9d7ab-ea9f-42fb-8394-7ce76ac9a2cb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                        

                    Соглашаюсь на обработку моих                         
                                        персональных данных                        

                    </value>
      <webElementGuid>b40aa98a-9c77-47de-9be2-545b477fecdc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;leyka-pf-18-star-form&quot;)/div[@class=&quot;section section--person&quot;]/div[@class=&quot;section__fields donor&quot;]/div[@class=&quot;donor__oferta invalid&quot;]/span[1]/label[2]</value>
      <webElementGuid>0b656e6e-1f9f-426f-ba5c-afcd2d3b3d5b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='leyka-pf-18-star-form']/div[5]/div[2]/div[3]/span/label[2]</value>
      <webElementGuid>05b66992-6601-477a-a08e-2ec5295ec6ba</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Укажите ваше имя'])[1]/following::label[2]</value>
      <webElementGuid>bff7c59c-971a-4e9b-8386-0537ce0b8adc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Лейке'])[1]/preceding::label[1]</value>
      <webElementGuid>8f6c5418-69ac-461a-82b7-cdae03deb8c9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Соглашаюсь на обработку моих']/parent::*</value>
      <webElementGuid>4acdda11-8a3c-4c6e-803b-bb689d6c6f9f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//label[2]</value>
      <webElementGuid>2a5ed6d6-4fed-4dc8-8384-d6fc77bdb799</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = '
                        

                    Соглашаюсь на обработку моих                         
                                        персональных данных                        

                    ' or . = '
                        

                    Соглашаюсь на обработку моих                         
                                        персональных данных                        

                    ')]</value>
      <webElementGuid>a52cf67c-0b87-43e1-a426-55a06cfc7ad0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
