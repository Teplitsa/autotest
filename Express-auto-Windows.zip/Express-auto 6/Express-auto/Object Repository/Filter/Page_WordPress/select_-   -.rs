<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_-   -</name>
   <tag></tag>
   <elementGuidId>8151bc40-9347-4646-b6ee-d2ddf0bd0a01</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#campaign-state-select</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>/html/body/div[1]/div[2]/div[2]/div[1]/div[3]/form[1]/div[1]/div[2]/select[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>79d3c384-7ccd-4ef3-9012-3ee4512e3d80</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>campaign-state-select</value>
      <webElementGuid>ce4d6ce7-ca38-49ec-8e40-c64edc1ea621</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>campaign_state</value>
      <webElementGuid>0e9e47fe-55ea-40f2-8520-3f7ad8e3d94c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>

            
                - Статус сбора -
            

            Закрыт

            Открыт

        </value>
      <webElementGuid>c5859a91-da9f-4d25-bb05-ba7185067f63</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;campaign-state-select&quot;)</value>
      <webElementGuid>0a30f20e-2454-4b17-a509-1fee81db296b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='campaign-state-select']</value>
      <webElementGuid>80585f23-76e6-4993-bade-7eec0ea200d0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='posts-filter']/div/div[2]/select[2]</value>
      <webElementGuid>642c3bcc-ce20-44b6-adc0-6cdda44f2828</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Фильтр по дате'])[1]/following::select[2]</value>
      <webElementGuid>d1bb3cd2-a00d-4690-8604-fb6fb29bcfe4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Выберите массовое действие'])[1]/following::select[3]</value>
      <webElementGuid>7176b99b-5878-4af1-8f09-cfd824acd459</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Фильтровать по SEO Оценке'])[1]/preceding::select[3]</value>
      <webElementGuid>90d92e06-7f45-4b23-a5b1-3c114a312201</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Фильтровать по оценке читаемости'])[1]/preceding::select[4]</value>
      <webElementGuid>2654f7dd-730b-400d-96dc-1cc94cb930f9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select[2]</value>
      <webElementGuid>276d7a8e-e719-45ff-bd0a-cc88ef7838d7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@id = 'campaign-state-select' and @name = 'campaign_state' and (text() = '

            
                - Статус сбора -
            

            Закрыт

            Открыт

        ' or . = '

            
                - Статус сбора -
            

            Закрыт

            Открыт

        ')]</value>
      <webElementGuid>f63d46bf-f51d-4586-a6e1-b6fef0c6a7d9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
