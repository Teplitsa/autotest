<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_email</name>
   <tag></tag>
   <elementGuidId>99d7bf91-fad7-4d72-9bb5-b09e1f1cfc69</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='leyka-pf-18-star-form']/div[5]/div[2]/div/div/label/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.donor__textfield-label.leyka_donor_name-label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>93500c57-f42e-479b-8891-d31157fa3cb5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>donor__textfield-label leyka_donor_name-label</value>
      <webElementGuid>6ed873d5-eb45-4ddd-9dc2-423d8bbea856</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                            Ваш email                        </value>
      <webElementGuid>80cd03fa-2bdb-4a64-b152-3fd7daf039ab</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;leyka-pf-18-star-form&quot;)/div[@class=&quot;section section--person&quot;]/div[@class=&quot;section__fields donor&quot;]/div[@class=&quot;donor__textfield donor__textfield--email required&quot;]/div[@class=&quot;leyka-star-field-frame&quot;]/label[1]/span[@class=&quot;donor__textfield-label leyka_donor_name-label&quot;]</value>
      <webElementGuid>680b48be-9687-4650-8d43-358cfa153a33</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='leyka-pf-18-star-form']/div[5]/div[2]/div/div/label/span</value>
      <webElementGuid>0e21620c-dd4b-4ca1-8a60-964d43ab0c63</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ваши данные'])[1]/following::span[1]</value>
      <webElementGuid>bb4539b5-9bf4-48e2-900d-7141d669fc87</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ссылка скопировна'])[1]/following::span[1]</value>
      <webElementGuid>da5b89ae-d289-4ae0-87d1-91633b4d9cc0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Укажите корректный адрес email'])[1]/preceding::span[1]</value>
      <webElementGuid>ef667604-38fd-45a0-9d43-0de5c8c2134b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Имя и Фамилия'])[1]/preceding::span[2]</value>
      <webElementGuid>75f971d4-5859-400f-8884-84b1084a4564</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Ваш email']/parent::*</value>
      <webElementGuid>03e1e244-8aa9-4012-b5b9-bf44663cc768</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/label/span</value>
      <webElementGuid>448ba1ac-5134-434a-8835-d30e05f2472e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
                            Ваш email                        ' or . = '
                            Ваш email                        ')]</value>
      <webElementGuid>57618d2a-dae0-4f48-9014-9805d3e11c38</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
