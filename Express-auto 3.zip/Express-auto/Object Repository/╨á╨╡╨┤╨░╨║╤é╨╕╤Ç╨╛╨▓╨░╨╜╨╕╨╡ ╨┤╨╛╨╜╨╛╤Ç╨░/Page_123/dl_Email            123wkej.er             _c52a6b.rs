<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>dl_Email            123wkej.er             _c52a6b</name>
   <tag></tag>
   <elementGuidId>6e69f33b-3900-4e50-8029-6b5bf72c5279</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>dl</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='leyka_donor_info']/div[2]/div[2]/div[2]/dl</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>dl</value>
      <webElementGuid>cf79fce0-904e-4aae-8bb1-e221fde8762a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            Тип донора
            Разовый

            Email
            123@wkej.er

            

            Первое пожертвование
            25.08.2022

            Подписан на новости
            

            нет
            

            Кампании
            

            «Нужна помощь (произвольные поля)»
            
        </value>
      <webElementGuid>097f706d-db27-41a7-a3b4-23efaabbad54</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;leyka_donor_info&quot;)/div[@class=&quot;inside&quot;]/div[@class=&quot;donor-col-2&quot;]/div[@class=&quot;donor-info-details&quot;]/dl[1]</value>
      <webElementGuid>5f0dcc49-8846-401d-8519-b99b3b19d73f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='leyka_donor_info']/div[2]/div[2]/div[2]/dl</value>
      <webElementGuid>d6052d0e-53e0-4806-8edf-7bce62bfbc37</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Показать/скрыть панель: Данные донора'])[1]/following::dl[1]</value>
      <webElementGuid>d5e9a5d4-feed-447d-8f51-045016eee2de</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Переместить вниз'])[1]/following::dl[1]</value>
      <webElementGuid>9b2e4779-35e7-4beb-b416-366fdefa7f49</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//dl</value>
      <webElementGuid>f968f6c5-0615-4921-8b43-3d2510bf5ab4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//dl[(text() = '
            Тип донора
            Разовый

            Email
            123@wkej.er

            

            Первое пожертвование
            25.08.2022

            Подписан на новости
            

            нет
            

            Кампании
            

            «Нужна помощь (произвольные поля)»
            
        ' or . = '
            Тип донора
            Разовый

            Email
            123@wkej.er

            

            Первое пожертвование
            25.08.2022

            Подписан на новости
            

            нет
            

            Кампании
            

            «Нужна помощь (произвольные поля)»
            
        ')]</value>
      <webElementGuid>9ffca248-638b-4469-ac8f-9af6f0dcc929</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
