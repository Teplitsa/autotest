<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_</name>
   <tag></tag>
   <elementGuidId>076b4d35-2eac-45ba-9aea-7a7cbb647aad</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.donor-additional-field.donor__textfield.donor__textfield--date.donor__textfield--data.required.invalid > div.leyka-star-field-frame</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='leyka-pf-118-star-form']/div[3]/div[4]/div[2]/div[5]/div</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[@class = 'leyka-star-field-frame']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>7fc98b7c-cee5-4508-a71c-9f048b9f983c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>leyka-star-field-frame</value>
      <webElementGuid>a3dae2d5-5dee-4177-aebb-b49c6ed12a9f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>

                                
                                    дата 
                                

                                

                            </value>
      <webElementGuid>a23a6f59-33fb-4fdd-8d74-1a3c18df726c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;leyka-pf-118-star-form&quot;)/div[@class=&quot;currency-tab currency-rub&quot;]/div[@class=&quot;section section--person&quot;]/div[@class=&quot;section__fields donor&quot;]/div[@class=&quot;donor-additional-field donor__textfield donor__textfield--date donor__textfield--data required invalid&quot;]/div[@class=&quot;leyka-star-field-frame&quot;]</value>
      <webElementGuid>72991a4e-6f2d-4224-abcd-8902a28f395f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='leyka-pf-118-star-form']/div[3]/div[4]/div[2]/div[5]/div</value>
      <webElementGuid>135e5881-baf0-48a0-9a17-720524aa318a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='телефон'])[1]/following::div[3]</value>
      <webElementGuid>8f238aaf-cf62-40dd-be51-d32ee0ef7010</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='это текст'])[1]/following::div[6]</value>
      <webElementGuid>e9853d0b-4d75-488f-a2a3-144ff338760a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[5]/div</value>
      <webElementGuid>a0231e8d-1886-4bec-84f7-432ef5d9837e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '

                                
                                    дата 
                                

                                

                            ' or . = '

                                
                                    дата 
                                

                                

                            ')]</value>
      <webElementGuid>5898d0d5-fcfc-4d3d-981a-e8913b83c08f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
