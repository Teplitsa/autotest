<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_email</name>
   <tag></tag>
   <elementGuidId>8b9e34fe-d150-4e3c-a0aa-90d27587cdac</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.donor__textfield-label.leyka_donor_name-label</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='leyka-pf-112-star-form']/div[3]/div[4]/div[2]/div/div/label/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>a94890cf-4ca3-44e0-9b57-0ec950dc2a68</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>donor__textfield-label leyka_donor_name-label</value>
      <webElementGuid>2690fc30-9323-4991-a3c6-5db5530af2eb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                            Ваш email                        </value>
      <webElementGuid>dd606826-43ee-4f91-8cda-bcf4267f2786</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;leyka-pf-112-star-form&quot;)/div[@class=&quot;currency-tab currency-rub&quot;]/div[@class=&quot;section section--person&quot;]/div[@class=&quot;section__fields donor&quot;]/div[@class=&quot;donor__textfield donor__textfield--email required&quot;]/div[@class=&quot;leyka-star-field-frame&quot;]/label[1]/span[@class=&quot;donor__textfield-label leyka_donor_name-label&quot;]</value>
      <webElementGuid>21ddff1d-61b6-4a59-8fff-b467d550fe40</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='leyka-pf-112-star-form']/div[3]/div[4]/div[2]/div/div/label/span</value>
      <webElementGuid>06856cad-9732-46e9-9f16-339687cfecfb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ваши данные'])[1]/following::span[1]</value>
      <webElementGuid>856ee6a6-11b9-4284-9256-d23f32d489ca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Банковская платёжная квитанция'])[1]/following::span[1]</value>
      <webElementGuid>b9a14711-57c5-46d1-9111-f2aa4f9f6702</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Укажите корректный адрес email'])[1]/preceding::span[1]</value>
      <webElementGuid>c159130f-f1b2-4fd3-bbf7-afcf215acbc0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Имя и Фамилия'])[1]/preceding::span[2]</value>
      <webElementGuid>8c1dbc31-9ecc-41da-8164-9d0440325a87</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Ваш email']/parent::*</value>
      <webElementGuid>28e2854a-73bc-44f9-98fd-974f49366dbc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/label/span</value>
      <webElementGuid>556bce66-6aaa-4bb6-9b0a-a01504f56723</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
                            Ваш email                        ' or . = '
                            Ваш email                        ')]</value>
      <webElementGuid>1b739895-e1a6-4b21-923c-1db37ed64f4a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
