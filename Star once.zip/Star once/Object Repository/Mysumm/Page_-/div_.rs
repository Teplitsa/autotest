<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_</name>
   <tag></tag>
   <elementGuidId>f11e7ad4-5234-4eec-8d93-f9433063622c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.donor__textfield.donor__textfield--name.required.focus > div.leyka-star-field-frame</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='leyka-pf-112-star-form']/div[3]/div[4]/div[2]/div[2]/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>7e1a5f48-4ec9-4a0d-8b28-f9108c7886e1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>leyka-star-field-frame</value>
      <webElementGuid>30d6e08f-9650-4689-adb1-1b06f1d753de</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>

                            
                        
                            Имя и Фамилия                        
                            
                            

                        </value>
      <webElementGuid>003e3afc-29a3-4b6f-88b0-d95315621fa9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;leyka-pf-112-star-form&quot;)/div[@class=&quot;currency-tab currency-rub&quot;]/div[@class=&quot;section section--person&quot;]/div[@class=&quot;section__fields donor&quot;]/div[@class=&quot;donor__textfield donor__textfield--name required focus&quot;]/div[@class=&quot;leyka-star-field-frame&quot;]</value>
      <webElementGuid>23c4c867-382b-42b6-8be3-4fe935ceb661</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='leyka-pf-112-star-form']/div[3]/div[4]/div[2]/div[2]/div</value>
      <webElementGuid>a2f50582-4661-4f34-878a-3979fbb4ab0d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Укажите корректный адрес email'])[1]/following::div[2]</value>
      <webElementGuid>87c3f42e-818a-4e08-8206-cf04f224df12</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ваш email'])[1]/following::div[3]</value>
      <webElementGuid>cb75ff9b-1223-4ad6-9718-8ea83e568f30</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Укажите ваше имя'])[1]/preceding::div[1]</value>
      <webElementGuid>8159a522-4881-4d8e-912a-523fef671612</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div[2]/div[2]/div</value>
      <webElementGuid>4544c781-82d2-42ba-8769-029be47fa9d3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '

                            
                        
                            Имя и Фамилия                        
                            
                            

                        ' or . = '

                            
                        
                            Имя и Фамилия                        
                            
                            

                        ')]</value>
      <webElementGuid>fd9963ec-f94b-47e0-93aa-d79ba2537ea5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
