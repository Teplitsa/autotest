<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label__1</name>
   <tag></tag>
   <elementGuidId>06c30fd2-ae0c-4be7-a0e3-7eefc2349989</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='leyka-pf-112-star-form']/div[3]/div[4]/div[2]/div[3]/span/label[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>2c3d4aa1-d3dd-4b2b-86ba-64d01b8b252e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>for</name>
      <type>Main</type>
      <value>leyka-973189999</value>
      <webElementGuid>33f0a45f-fe28-4d79-bcbd-64e659342f36</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                        

                    Соглашаюсь на обработку моих                         
                                        персональных данных                        

                    </value>
      <webElementGuid>5089defa-06a5-44ea-b63b-6b0026ae032c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;leyka-pf-112-star-form&quot;)/div[@class=&quot;currency-tab currency-rub&quot;]/div[@class=&quot;section section--person&quot;]/div[@class=&quot;section__fields donor&quot;]/div[@class=&quot;donor__oferta invalid&quot;]/span[1]/label[2]</value>
      <webElementGuid>e0b2537f-66f9-4de8-bfdc-f5a7a216a095</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='leyka-pf-112-star-form']/div[3]/div[4]/div[2]/div[3]/span/label[2]</value>
      <webElementGuid>d47768ce-fbf6-4d33-8bdd-8299407e4254</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Укажите ваше имя'])[1]/following::label[2]</value>
      <webElementGuid>1adadf62-d87f-4b9e-b834-71d1b5c89998</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='crypto wallets addresses'])[1]/preceding::label[1]</value>
      <webElementGuid>c242dfda-84a9-4521-af40-3897bf708d89</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='We also accept donations in cryptocurrencies'])[1]/preceding::label[1]</value>
      <webElementGuid>71d96af0-ad0b-41a1-ac13-2c0ce92c34bd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Соглашаюсь на обработку моих']/parent::*</value>
      <webElementGuid>a7e3958a-ca3c-41e8-9093-34e34339231c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//label[2]</value>
      <webElementGuid>1c96437a-0833-49f4-ad51-e5c1fcf22db7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = '
                        

                    Соглашаюсь на обработку моих                         
                                        персональных данных                        

                    ' or . = '
                        

                    Соглашаюсь на обработку моих                         
                                        персональных данных                        

                    ')]</value>
      <webElementGuid>01ff17e8-4be0-4695-8454-27b38f7efa76</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
