<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_</name>
   <tag></tag>
   <elementGuidId>0854c69c-f02b-41de-a714-3a979d4d792b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span > label</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='leyka-pf-118-star-form']/div[3]/div[4]/div[2]/div[6]/span/label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>6c7fbb51-1b9c-4938-ab6a-4f7e8e7a9a38</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>for</name>
      <type>Main</type>
      <value>leyka-1362981187</value>
      <webElementGuid>0d831fdc-1878-4ebe-82da-ccf34624b745</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                        

                    Соглашаюсь с                         
                                        офертой                        
                    </value>
      <webElementGuid>b5c69a91-c539-4e8e-99d3-f8e9b0918755</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;leyka-pf-118-star-form&quot;)/div[@class=&quot;currency-tab currency-rub&quot;]/div[@class=&quot;section section--person&quot;]/div[@class=&quot;section__fields donor&quot;]/div[@class=&quot;donor__oferta&quot;]/span[1]/label[1]</value>
      <webElementGuid>b758fa41-6738-4b61-8be8-5a32de580d05</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='leyka-pf-118-star-form']/div[3]/div[4]/div[2]/div[6]/span/label</value>
      <webElementGuid>0b6ffbb3-23f6-49b3-9cd5-087b13cb01c1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='дата'])[1]/following::label[1]</value>
      <webElementGuid>0745d212-4001-4296-b25b-98cf42c917b8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='телефон'])[1]/following::label[2]</value>
      <webElementGuid>4661387a-6a0f-4d45-a020-ab794458884f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='crypto wallets addresses'])[1]/preceding::label[2]</value>
      <webElementGuid>c482780c-82c8-4bb9-8353-3484096a4830</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Соглашаюсь с']/parent::*</value>
      <webElementGuid>f16bb1af-548c-4357-8512-c914790a6fd0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span/label</value>
      <webElementGuid>16f93757-f8f1-4275-ab1a-229c71c808b4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = '
                        

                    Соглашаюсь с                         
                                        офертой                        
                    ' or . = '
                        

                    Соглашаюсь с                         
                                        офертой                        
                    ')]</value>
      <webElementGuid>6b4f2042-17d5-4844-bb8c-e9abe92223a8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
