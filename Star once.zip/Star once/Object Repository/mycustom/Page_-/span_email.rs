<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_email</name>
   <tag></tag>
   <elementGuidId>d572f44b-a003-43a8-9df9-3d2007cfe80d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.donor__textfield-label.leyka_donor_name-label</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='leyka-pf-118-star-form']/div[3]/div[4]/div[2]/div/div/label/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>f625fb30-2a43-4d4a-b190-48671a255b4e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>donor__textfield-label leyka_donor_name-label</value>
      <webElementGuid>72760a4d-e6cf-4322-8d0d-1a73704d08cc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                            Ваш email                        </value>
      <webElementGuid>95a8d3af-2701-48dd-9e3c-9c322ee88820</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;leyka-pf-118-star-form&quot;)/div[@class=&quot;currency-tab currency-rub&quot;]/div[@class=&quot;section section--person&quot;]/div[@class=&quot;section__fields donor&quot;]/div[@class=&quot;donor__textfield donor__textfield--email required&quot;]/div[@class=&quot;leyka-star-field-frame&quot;]/label[1]/span[@class=&quot;donor__textfield-label leyka_donor_name-label&quot;]</value>
      <webElementGuid>3118f19f-7cd0-4777-8d6c-bd713fea0294</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='leyka-pf-118-star-form']/div[3]/div[4]/div[2]/div/div/label/span</value>
      <webElementGuid>06d5b6c2-a741-4ff5-99cc-211f84dd5791</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ваши данные'])[1]/following::span[1]</value>
      <webElementGuid>6df8a87d-23ec-45c7-ad58-892f874d3bd5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Банковская платёжная квитанция'])[1]/following::span[1]</value>
      <webElementGuid>71d9e3e8-1543-4724-9548-29a198376b4b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Укажите корректный адрес email'])[1]/preceding::span[1]</value>
      <webElementGuid>370ac146-ffae-4ba3-96f9-bf3afd548bcf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Имя и Фамилия'])[1]/preceding::span[2]</value>
      <webElementGuid>a1994ff9-0f73-4f2d-83eb-0ba8608a378d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Ваш email']/parent::*</value>
      <webElementGuid>ebcd2b7e-efae-4a45-8b42-e6c311b8d81d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/label/span</value>
      <webElementGuid>de3f1504-b7c6-4c47-9453-f7fc8ea38d86</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
                            Ваш email                        ' or . = '
                            Ваш email                        ')]</value>
      <webElementGuid>18560b6d-684e-4fa6-aea1-62741dbbc01f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
