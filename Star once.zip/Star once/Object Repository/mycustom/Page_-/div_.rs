<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_</name>
   <tag></tag>
   <elementGuidId>6213ad6c-a923-460e-a222-fcd993f18c72</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.payment-opt.swiper-item.selected > div.swiper-item-inner</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='leyka-pf-118-star-form']/div[3]/div[3]/div[2]/div/div[3]/div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>96076691-e407-4445-b8b2-e9fd0c71395d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>swiper-item-inner</value>
      <webElementGuid>e6596ddc-d662-4b3d-8204-9e05ada14c3d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>

                                        

                                            

                                            
                                                                            
                                                                            
                                                                            
                                                                            
                                                                    

                                        

                                        Банковская карта

                                    </value>
      <webElementGuid>f7a906b8-db94-464d-b75a-43899fb08368</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;leyka-pf-118-star-form&quot;)/div[@class=&quot;currency-tab currency-rub&quot;]/div[@class=&quot;section section--cards&quot;]/div[@class=&quot;section__fields payments-grid&quot;]/div[@class=&quot;star-swiper no-swipe only-one-item show-right-arrow&quot;]/div[@class=&quot;full-list&quot;]/div[@class=&quot;payment-opt swiper-item selected&quot;]/div[@class=&quot;swiper-item-inner&quot;]</value>
      <webElementGuid>bb6e5aed-f087-4247-8f30-71c812dae691</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='leyka-pf-118-star-form']/div[3]/div[3]/div[2]/div/div[3]/div/div</value>
      <webElementGuid>aec12668-95c9-4e18-9f8a-976735e2b56a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Способ оплаты'])[1]/following::div[7]</value>
      <webElementGuid>b0892eb3-fc8c-4944-afb2-7cff321011a5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='₽'])[10]/following::div[12]</value>
      <webElementGuid>2b626763-0011-4dc3-9431-245da64d323d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Банковская платёжная квитанция'])[1]/preceding::div[1]</value>
      <webElementGuid>73fb9ba0-5ee4-451e-9905-e42e2382a274</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div[2]/div/div[3]/div/div</value>
      <webElementGuid>849e84d1-a3a7-41d3-88ac-32cfdf43e318</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '

                                        

                                            

                                            
                                                                            
                                                                            
                                                                            
                                                                            
                                                                    

                                        

                                        Банковская карта

                                    ' or . = '

                                        

                                            

                                            
                                                                            
                                                                            
                                                                            
                                                                            
                                                                    

                                        

                                        Банковская карта

                                    ')]</value>
      <webElementGuid>d8c6ee6c-2a85-4f55-9e4f-082790797a2f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
