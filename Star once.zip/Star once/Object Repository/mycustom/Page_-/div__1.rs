<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div__1</name>
   <tag></tag>
   <elementGuidId>431efa51-5e6e-4f46-9ef5-8f521932cf46</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.donor-additional-field.donor__textfield.donor__textfield--text.donor__textfield--eto-tekst.required.focus > div.leyka-star-field-frame</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='leyka-pf-118-star-form']/div[3]/div[4]/div[2]/div[3]/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>2e8a70a4-7ed1-4540-ba6d-2b9ca109cb0c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>leyka-star-field-frame</value>
      <webElementGuid>a936bc3d-3f99-464d-82af-4d33771f6077</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>

                                
                                    это текст
                                

                                

                            </value>
      <webElementGuid>53386d29-a1df-42aa-8a8b-ff935dba1625</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;leyka-pf-118-star-form&quot;)/div[@class=&quot;currency-tab currency-rub&quot;]/div[@class=&quot;section section--person&quot;]/div[@class=&quot;section__fields donor&quot;]/div[@class=&quot;donor-additional-field donor__textfield donor__textfield--text donor__textfield--eto-tekst required focus&quot;]/div[@class=&quot;leyka-star-field-frame&quot;]</value>
      <webElementGuid>28f36a45-d1ef-4e88-a9cf-76c636aabde5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='leyka-pf-118-star-form']/div[3]/div[4]/div[2]/div[3]/div</value>
      <webElementGuid>d6b37e1a-bdb2-40b8-9a9d-c1b1f9716cc3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Укажите ваше имя'])[1]/following::div[2]</value>
      <webElementGuid>ba17fff8-5206-4817-850f-a219c8382659</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Имя и Фамилия'])[1]/following::div[3]</value>
      <webElementGuid>6b1daa3a-d382-4b0e-955a-b8e4dd23af53</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='телефон'])[1]/preceding::div[2]</value>
      <webElementGuid>10ba4d51-058b-41da-ba04-70cfa9a55182</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[3]/div</value>
      <webElementGuid>ef179fce-9705-43a0-add7-85bf6d4a9c48</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '

                                
                                    это текст
                                

                                

                            ' or . = '

                                
                                    это текст
                                

                                

                            ')]</value>
      <webElementGuid>9ce2069d-5184-493c-9bce-0a9c6c4771b0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
