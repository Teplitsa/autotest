<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_</name>
   <tag></tag>
   <elementGuidId>70bc462a-4d14-4e40-b5ef-b9d04ee76393</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.donor__textfield.donor__textfield--name.required > div.leyka-star-field-frame > label > span.donor__textfield-label.leyka_donor_name-label</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='leyka-pf-118-star-form']/div[3]/div[4]/div[2]/div[2]/div/label/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>7acd4b0d-54d1-4421-9df3-7f259f7e04b6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>donor__textfield-label leyka_donor_name-label</value>
      <webElementGuid>7ede4b04-419d-4e83-9816-f2688147f93a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                            Имя и Фамилия                        </value>
      <webElementGuid>3416fdaf-5117-464f-a757-0676ef1691d3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;leyka-pf-118-star-form&quot;)/div[@class=&quot;currency-tab currency-rub&quot;]/div[@class=&quot;section section--person&quot;]/div[@class=&quot;section__fields donor&quot;]/div[@class=&quot;donor__textfield donor__textfield--name required&quot;]/div[@class=&quot;leyka-star-field-frame&quot;]/label[1]/span[@class=&quot;donor__textfield-label leyka_donor_name-label&quot;]</value>
      <webElementGuid>d0455059-7886-4ef2-b994-5d186407e243</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='leyka-pf-118-star-form']/div[3]/div[4]/div[2]/div[2]/div/label/span</value>
      <webElementGuid>a4c7d056-4eda-40e5-a081-b291c6a736a0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Укажите корректный адрес email'])[1]/following::span[1]</value>
      <webElementGuid>1c5bb22e-e242-47bf-aa70-3c07c034f62b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ваш email'])[1]/following::span[2]</value>
      <webElementGuid>dc5af7dc-c36c-4c9f-bfe3-03c58e3f7dea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Укажите ваше имя'])[1]/preceding::span[1]</value>
      <webElementGuid>4d1ba073-d967-43f4-958f-3bff783d69ba</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='это текст'])[1]/preceding::span[2]</value>
      <webElementGuid>978eba4a-1d2f-4d36-bc2d-907bf2c6651e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Имя и Фамилия']/parent::*</value>
      <webElementGuid>472808de-f9b7-41cd-88b8-1f8efbf4ad6d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[2]/div/label/span</value>
      <webElementGuid>f1475967-4490-4b62-847d-1ae03a41eae4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
                            Имя и Фамилия                        ' or . = '
                            Имя и Фамилия                        ')]</value>
      <webElementGuid>004e4f18-4cee-4a90-9100-18f17aa55cdf</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
