<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div__1_2</name>
   <tag></tag>
   <elementGuidId>db018641-1872-444e-a7f7-85ad1954e9b4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.donor-additional-field.donor__textfield.donor__textfield--phone.donor__textfield--telefon.required.invalid > div.leyka-star-field-frame</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='leyka-pf-118-star-form']/div[3]/div[4]/div[2]/div[4]/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>3a9cbe6a-4a6f-49a8-ac98-5c4259209649</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>leyka-star-field-frame</value>
      <webElementGuid>eeb4e60f-4b07-47fc-9c5a-0448e1c52196</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>

                                
                                    телефон
                                

                                

                            </value>
      <webElementGuid>1d0739bf-95dc-443e-af9b-b3ef1225e622</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;leyka-pf-118-star-form&quot;)/div[@class=&quot;currency-tab currency-rub&quot;]/div[@class=&quot;section section--person&quot;]/div[@class=&quot;section__fields donor&quot;]/div[@class=&quot;donor-additional-field donor__textfield donor__textfield--phone donor__textfield--telefon required invalid&quot;]/div[@class=&quot;leyka-star-field-frame&quot;]</value>
      <webElementGuid>9e515a45-008f-4425-9c5b-e8df2e66281c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='leyka-pf-118-star-form']/div[3]/div[4]/div[2]/div[4]/div</value>
      <webElementGuid>9a54f49d-1307-4558-a82a-cc9756b23a5a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='это текст'])[1]/following::div[3]</value>
      <webElementGuid>f07209b4-6c9c-48d0-b69e-4887f7a5a242</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Укажите ваше имя'])[1]/following::div[5]</value>
      <webElementGuid>f686c44b-6ca0-4e5b-90a2-a96fa22222ec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='дата'])[1]/preceding::div[2]</value>
      <webElementGuid>a5432f3e-9dfe-468f-86aa-caf7f47a8326</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[4]/div</value>
      <webElementGuid>ee80d367-2fdc-4931-b211-31564698a5c0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '

                                
                                    телефон
                                

                                

                            ' or . = '

                                
                                    телефон
                                

                                

                            ')]</value>
      <webElementGuid>5032c21d-cbb4-4280-9ec9-de2dd270956a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
