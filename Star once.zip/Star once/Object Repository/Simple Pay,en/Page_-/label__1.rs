<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label__1</name>
   <tag></tag>
   <elementGuidId>a46ab956-bd29-4094-b4ea-0fa3e0f407d1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='leyka-pf-112-star-form']/div[3]/div[4]/div[2]/div[3]/span/label[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>cba2321b-77b0-420e-b3d2-dfa2992bca64</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>for</name>
      <type>Main</type>
      <value>leyka-3427113225</value>
      <webElementGuid>eebd90e0-6aec-4efa-8099-55fcba77ff6e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                        

                    Соглашаюсь на обработку моих                         
                                        персональных данных                        

                    </value>
      <webElementGuid>7bce9de0-82ef-403d-867d-67b2859ef450</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;leyka-pf-112-star-form&quot;)/div[@class=&quot;currency-tab currency-rub&quot;]/div[@class=&quot;section section--person&quot;]/div[@class=&quot;section__fields donor&quot;]/div[@class=&quot;donor__oferta invalid&quot;]/span[1]/label[2]</value>
      <webElementGuid>b4929110-9f4f-4703-b5c9-16087b91d4b8</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='leyka-pf-112-star-form']/div[3]/div[4]/div[2]/div[3]/span/label[2]</value>
      <webElementGuid>edb218ac-1cbc-4480-859c-329675b21945</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Укажите ваше имя'])[1]/following::label[2]</value>
      <webElementGuid>3ba07d85-dbfe-425a-8124-b348a08e60f8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='crypto wallets addresses'])[1]/preceding::label[1]</value>
      <webElementGuid>0a267bcc-f9e4-45df-92db-fc830d42cedd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='We also accept donations in cryptocurrencies'])[1]/preceding::label[1]</value>
      <webElementGuid>1fe8dbf8-8e68-4336-aa9c-af8ed0d49b8c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Соглашаюсь на обработку моих']/parent::*</value>
      <webElementGuid>6b2a2ff2-bdea-4364-882f-fec9b3bed61e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//label[2]</value>
      <webElementGuid>a42fc2b3-34be-4138-b03b-06dd54c35b59</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = '
                        

                    Соглашаюсь на обработку моих                         
                                        персональных данных                        

                    ' or . = '
                        

                    Соглашаюсь на обработку моих                         
                                        персональных данных                        

                    ')]</value>
      <webElementGuid>eb913a35-c62d-4e87-bd6c-b00bf5fcb9ca</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
