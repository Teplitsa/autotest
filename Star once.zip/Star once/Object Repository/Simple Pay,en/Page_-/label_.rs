<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_</name>
   <tag></tag>
   <elementGuidId>83852f5f-c996-4071-a61e-dd0294b5e1d1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span > label</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='leyka-pf-112-star-form']/div[3]/div[4]/div[2]/div[3]/span/label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>2bc6ffae-eb36-456b-86e1-9d3ccca42687</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>for</name>
      <type>Main</type>
      <value>leyka-2141170920</value>
      <webElementGuid>02495071-d62b-442c-875b-3df3d675eaa6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                        

                    Соглашаюсь с                         
                                        офертой                        
                    </value>
      <webElementGuid>b0ed4887-c3a3-4538-b695-a0379d339622</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;leyka-pf-112-star-form&quot;)/div[@class=&quot;currency-tab currency-rub&quot;]/div[@class=&quot;section section--person&quot;]/div[@class=&quot;section__fields donor&quot;]/div[@class=&quot;donor__oferta&quot;]/span[1]/label[1]</value>
      <webElementGuid>c366b0c4-bbeb-4eae-864d-c6dfdd1b7b60</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='leyka-pf-112-star-form']/div[3]/div[4]/div[2]/div[3]/span/label</value>
      <webElementGuid>753622a5-6cea-4d37-8fef-89661eceb231</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Укажите ваше имя'])[1]/following::label[1]</value>
      <webElementGuid>e78fba02-906e-4c0f-a4c8-09e7db82086b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Имя и Фамилия'])[1]/following::label[1]</value>
      <webElementGuid>1539d23b-d177-4bad-94a9-d4025b4ee5e0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='crypto wallets addresses'])[1]/preceding::label[2]</value>
      <webElementGuid>e260232e-e2e8-444d-a718-7a1bf32486fa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Соглашаюсь с']/parent::*</value>
      <webElementGuid>d5cd1c3e-bd46-48c3-8a8f-44fca36de8be</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span/label</value>
      <webElementGuid>0f5a8ae4-c784-4849-975e-1fb72ba4f763</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = '
                        

                    Соглашаюсь с                         
                                        офертой                        
                    ' or . = '
                        

                    Соглашаюсь с                         
                                        офертой                        
                    ')]</value>
      <webElementGuid>a7b0dc4b-c008-46ca-9026-1039f9e219e9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
