<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_</name>
   <tag></tag>
   <elementGuidId>d28569cf-c0c4-4033-b8eb-87c1d3f9bf4e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='leyka-pf-118-star-form']/div[3]/div[4]/div[2]/div[6]/span/label[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>80472b44-107d-4af2-9987-4fa26680e788</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>for</name>
      <type>Main</type>
      <value>leyka-1824385649</value>
      <webElementGuid>685abf93-f507-4c0a-b821-8ed74bf58e58</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                        

                    Соглашаюсь на обработку моих                         
                                        персональных данных                        

                    </value>
      <webElementGuid>cf084dbf-db62-4864-ab97-d49290899676</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;leyka-pf-118-star-form&quot;)/div[@class=&quot;currency-tab currency-rub&quot;]/div[@class=&quot;section section--person&quot;]/div[@class=&quot;section__fields donor&quot;]/div[@class=&quot;donor__oferta invalid&quot;]/span[1]/label[2]</value>
      <webElementGuid>8e12fc3a-6d48-4304-8b49-21473f6550c1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='leyka-pf-118-star-form']/div[3]/div[4]/div[2]/div[6]/span/label[2]</value>
      <webElementGuid>440944f6-b0f7-447d-87ec-c93b653fde43</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='дата'])[1]/following::label[2]</value>
      <webElementGuid>c4e575ec-766e-44a1-b39d-9202a5704c40</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='crypto wallets addresses'])[1]/preceding::label[1]</value>
      <webElementGuid>f87c3b8c-8e02-485c-9c39-2246e5d73433</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='We also accept donations in cryptocurrencies'])[1]/preceding::label[1]</value>
      <webElementGuid>816270ec-1096-4c6e-a650-d3017960c346</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Соглашаюсь на обработку моих']/parent::*</value>
      <webElementGuid>c208ae90-6ddd-468e-b586-a62f56ecb01c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//label[2]</value>
      <webElementGuid>6f585cf6-c39d-400a-be31-cd9fb0c5c4d2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = '
                        

                    Соглашаюсь на обработку моих                         
                                        персональных данных                        

                    ' or . = '
                        

                    Соглашаюсь на обработку моих                         
                                        персональных данных                        

                    ')]</value>
      <webElementGuid>cc99e593-f4c2-4316-ab2d-f920f29718be</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
