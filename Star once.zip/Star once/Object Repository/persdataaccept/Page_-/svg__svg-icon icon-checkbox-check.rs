<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>svg__svg-icon icon-checkbox-check</name>
   <tag></tag>
   <elementGuidId>a4ac8098-2206-4ba1-bddc-56f56067d250</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='crypto wallets addresses'])[1]/preceding::*[name()='svg'][1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>svg</value>
      <webElementGuid>3d0f6066-5368-459b-b487-56ee6fc63e60</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>svg-icon icon-checkbox-check</value>
      <webElementGuid>3faadbd1-ad7a-4c94-8bc8-98a1fe60de6a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;leyka-pf-118-star-form&quot;)/div[@class=&quot;currency-tab currency-rub&quot;]/div[@class=&quot;section section--person&quot;]/div[@class=&quot;section__fields donor&quot;]/div[@class=&quot;donor__oferta invalid&quot;]/span[1]/label[2]/svg[@class=&quot;svg-icon icon-checkbox-check&quot;]</value>
      <webElementGuid>301a0cd8-0ad4-4e07-a245-8058cda8d703</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='crypto wallets addresses'])[1]/preceding::*[name()='svg'][1]</value>
      <webElementGuid>9152e5f2-2cb0-4ada-8ffe-051178feafbf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='We also accept donations in cryptocurrencies'])[1]/preceding::*[name()='svg'][1]</value>
      <webElementGuid>aa1c2a99-af13-493c-8cae-73a0ddcca00f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
